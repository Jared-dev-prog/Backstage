export const Messages = {
  generic: 'Lo sentimos, ocurrió un error inesperado',
  timeout: 'Ocurrió un error en el servidor, el tiempo de espera se ha agotado',
};
