export enum GoogleLogEvents {
  exception = 'exception',
}

export enum LoggerStrategies {
  GOOGLE = 'GoogleStrategy',
}
