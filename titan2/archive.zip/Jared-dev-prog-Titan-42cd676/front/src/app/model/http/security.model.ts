// MODELO DE EJEMPLO, BORRAR EN PROYECTO REAL

export interface ILoginReq {
  email: string;
  password: string;
}

export interface ILoginRes {
  token: string;
}
