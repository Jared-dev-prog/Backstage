export interface IBaseResponseHttp {
  code: number;
  success: boolean;
  message: string;
}
