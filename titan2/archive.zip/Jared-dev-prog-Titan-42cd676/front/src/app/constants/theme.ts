export const LightThemes = [ 'default', 'axity' ]
