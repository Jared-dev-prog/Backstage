import * as microService from './micro';

export {
    microService
}